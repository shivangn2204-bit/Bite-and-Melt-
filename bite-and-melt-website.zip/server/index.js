import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import Razorpay from 'razorpay';
import crypto from 'node:crypto';
import Database from 'better-sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 4242);
const db = new Database(path.join(__dirname, 'orders.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, customer_phone TEXT NOT NULL,
 fulfilment TEXT NOT NULL, address TEXT, payment_method TEXT NOT NULL,
 amount_paise INTEGER NOT NULL, status TEXT NOT NULL, payment_id TEXT,
 items_json TEXT NOT NULL, created_at TEXT NOT NULL
);
`);
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET}) : null;
const rateLimitOrders = rateLimit({windowMs:15*60*1000,limit:30,standardHeaders:true,legacyHeaders:false});
app.use(cors({origin: process.env.PUBLIC_SITE_URL || 'http://localhost:5173'}));
app.use(express.json({limit:'100kb', verify:(req,_res,buf)=>{ if(req.originalUrl==='/api/payments/webhook') req.rawBody=Buffer.from(buf); }}));

const menuPrices = new Map([
 ['Bite and Melt Sp. Burger',40],['Veg Burger',40],['Capsi-Crunch Pizza',149],['Spicy Peri Peri Veg. Pizza',159],['Veg Carnival Pizza',169],['Signature Cheese Pizza',169],['Tandoori Paneer Pizza',179],
 ['Cold Coffee',40],['Hazelnut Cold Coffee',50],['Caramel Cold Coffee',50],['Chocolate Cold Coffee',50],
 ['Bread Butter',40],['Bread Butter Jam',40],['Veg Sandwich',50],['Cheese Chutney Sandwich',60],['Corn Cheese Sandwich',70],['Veg. Cheese Grill',70],['Aloo Cheese Chutney',70],['Paneer Makhani',70],['Cheese Chilli Sandwich',70],['Bite & Melt Sp. Sandwich',80],['Paneer Makhani Cheese',90],
 ['Garlic Bread',70],['Masala Maggi',50],['Veg. Maggi',60],['Veg. Cheese Maggi',80],['Salted Fries',60],['Peri Peri Fries',70],['Cheese Fries',80]
]);
const insertOrder = db.prepare(`INSERT INTO orders(id,customer_name,customer_phone,fulfilment,address,payment_method,amount_paise,status,payment_id,items_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`);
const getOrder = db.prepare('SELECT * FROM orders WHERE id=?');
const updateOrder = db.prepare('UPDATE orders SET status=?, payment_id=? WHERE id=?');

function validateOrder(body) {
 const c=body?.customer, items=body?.items;
 if(!c || typeof c.name!=='string' || c.name.trim().length<2 || c.name.length>100) throw new Error('Enter a valid name');
 if(typeof c.phone!=='string' || !/^[0-9+ ()-]{10,18}$/.test(c.phone)) throw new Error('Enter a valid phone number');
 if(!['Delivery','Pickup'].includes(c.fulfilment)) throw new Error('Choose delivery or pickup');
 if(c.fulfilment==='Delivery' && (typeof c.address!=='string' || c.address.trim().length<8 || c.address.length>500)) throw new Error('Enter a complete delivery address');
 if(!['Online','Cash on Delivery'].includes(c.payment)) throw new Error('Choose a valid payment method');
 if(!Array.isArray(items) || items.length<1 || items.length>30) throw new Error('Cart is empty or too large');
 let total=0;
 const clean=items.map(i=>{
  if(!i || !menuPrices.has(i.name) || !Number.isInteger(i.qty) || i.qty<1 || i.qty>50) throw new Error('Invalid menu item or quantity');
  const price=menuPrices.get(i.name); total+=price*i.qty;
  return {name:i.name,price,qty:i.qty};
 });
 if(total<1 || total>100000) throw new Error('Order total is out of range');
 return {c,clean,total};
}
async function notifyCafe(order, statusLabel) {
 const token=process.env.WHATSAPP_ACCESS_TOKEN, phoneId=process.env.WHATSAPP_PHONE_NUMBER_ID, to=process.env.CAFE_WHATSAPP_TO;
 if(!token || !phoneId || !to) { console.warn('WhatsApp credentials not configured; order notification skipped.'); return false; }
 const items=JSON.parse(order.items_json).map(i=>`• ${i.name} x${i.qty} — ₹${i.price*i.qty}`).join('\n');
 const textMsg=`BITE AND MELT — ${statusLabel}\nOrder: ${order.id}\nCustomer: ${order.customer_name}\nPhone: ${order.customer_phone}\nType: ${order.fulfilment}\n${order.address?`Address: ${order.address}\n`:''}Items:\n${items}\nTotal: ₹${order.amount_paise/100}\nPayment: ${order.payment_method}${order.payment_id?`\nPayment ID: ${order.payment_id}`:''}`;
 const response=await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',recipient_type:'individual',to,type:'text',text:{preview_url:false,body:textMsg}})});
 if(!response.ok) { console.error('WhatsApp notification failed:', await response.text()); return false; }
 return true;
}
app.get('/api/health',(_req,res)=>res.json({ok:true,onlinePaymentsConfigured:Boolean(razorpay),whatsappConfigured:Boolean(process.env.WHATSAPP_ACCESS_TOKEN&&process.env.WHATSAPP_PHONE_NUMBER_ID&&process.env.CAFE_WHATSAPP_TO)}));

app.post('/api/orders',rateLimitOrders,async(req,res)=>{
 let parsed; try {parsed=validateOrder(req.body);} catch(e){return res.status(400).json({error:e.message});}
 const {c,clean,total}=parsed;
 const id='BM-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(2).toString('hex').toUpperCase();
 const isOnline=c.payment==='Online';
 if(isOnline && !razorpay) return res.status(503).json({error:'Online payment is not configured yet. Please use Cash on Delivery or try later.'});
 let rzpOrderId=null;
 try {
  if(isOnline) {
   const rzp=await razorpay.orders.create({amount:total*100,currency:'INR',receipt:id,notes:{cafe_order_id:id}});
   rzpOrderId=rzp.id;
  }
  insertOrder.run(id,c.name.trim(),c.phone.trim(),c.fulfilment,c.fulfilment==='Delivery'?c.address.trim():'',c.payment,total*100,isOnline?'AWAITING_PAYMENT':'PLACED',null,JSON.stringify(clean),new Date().toISOString());
  const saved=getOrder.get(id);
  if(!isOnline) await notifyCafe(saved,'COD / PAY AT PICKUP ORDER — PENDING CAFE ACCEPTANCE');
  res.status(201).json({orderId:id,amountPaise:total*100,razorpayOrderId:rzpOrderId,razorpayKeyId:isOnline?process.env.RAZORPAY_KEY_ID:null,status:isOnline?'AWAITING_PAYMENT':'PLACED'});
 } catch(e) { console.error('Order creation error:',e); res.status(500).json({error:'Could not create order. Please try again.'}); }
});

app.post('/api/payments/verify',rateLimitOrders,(req,res)=>{
 const {razorpay_order_id,razorpay_payment_id,razorpay_signature,orderId}=req.body||{};
 if(!razorpay || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !orderId) return res.status(400).json({error:'Missing payment verification details'});
 const order=getOrder.get(orderId);
 if(!order || order.status!=='AWAITING_PAYMENT') return res.status(400).json({error:'Order not found or already processed'});
 const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
 const a=Buffer.from(expected), b=Buffer.from(String(razorpay_signature));
 if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return res.status(400).json({error:'Payment signature verification failed'});
 // Ensure the Razorpay order matches this local order before marking paid.
 razorpay.orders.fetch(razorpay_order_id).then(async rz=>{
  if(rz.receipt!==orderId || Number(rz.amount)!==order.amount_paise) return res.status(400).json({error:'Payment amount/order mismatch'});
  updateOrder.run('PAID',razorpay_payment_id,orderId);
  const updated=getOrder.get(orderId); await notifyCafe(updated,'PAYMENT VERIFIED — ORDER CONFIRMED');
  res.json({ok:true,orderId,status:'PAID'});
 }).catch(err=>{console.error('Razorpay verification error:',err);res.status(502).json({error:'Could not verify payment with payment provider. Please contact the cafe before retrying.'});});
});

// Optional Razorpay webhook. Configure this URL and secret in Razorpay Dashboard.
// Raw body is needed for webhook signature verification, so this route reads its own raw body.
app.post('/api/payments/webhook',async(req,res)=>{
 const secret=process.env.RAZORPAY_WEBHOOK_SECRET;
 if(!secret) return res.status(503).send('Webhook secret not configured');
 const signature=req.get('x-razorpay-signature')||'';
 const rawBody=req.rawBody;
 if(!rawBody) return res.status(400).send('Missing raw webhook body');
 const expected=crypto.createHmac('sha256',secret).update(rawBody).digest('hex');
 const a=Buffer.from(expected),b=Buffer.from(signature);
 if(a.length!==b.length||!crypto.timingSafeEqual(a,b)) return res.status(400).send('Invalid signature');
 let event; try{event=JSON.parse(rawBody.toString('utf8'));}catch{return res.status(400).send('Invalid JSON');}
 if(event.event==='payment.captured'||event.event==='order.paid'){
  const payment=event.payload?.payment?.entity;
  const rzOrderId=payment?.order_id;
  if(rzOrderId){
   const found=db.prepare("SELECT * FROM orders WHERE status='AWAITING_PAYMENT'").all();
   for(const order of found){
    try{
     const rz=await razorpay.orders.fetch(rzOrderId);
     if(rz.receipt===order.id && Number(rz.amount)===order.amount_paise){
      updateOrder.run('PAID',payment.id,order.id); await notifyCafe(getOrder.get(order.id),'PAYMENT VERIFIED — ORDER CONFIRMED');
     }
    }catch(err){console.error('Webhook processing error:',err);}
   }
  }
 }
 res.json({received:true});
});

if(process.env.NODE_ENV==='production') {
 const dist=path.resolve(__dirname,'../dist');
 app.use(express.static(dist));
 app.get('*',(req,res)=>res.sendFile(path.join(dist,'index.html')));
}
app.listen(port,()=>console.log(`Bite and Melt server listening on http://localhost:${port}`));
