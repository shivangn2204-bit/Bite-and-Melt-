# Bite and Melt — animated food-ordering website

A responsive React/Vite storefront with the menu transcribed from the supplied cafe menu, cart, delivery/pickup checkout, Cash on Delivery/pay-at-pickup, Razorpay checkout integration, server-side signature verification, SQLite order records, and WhatsApp Cloud API notifications.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal (normally http://localhost:5173). The backend runs at http://localhost:4242.

Cash-on-delivery and pay-at-pickup orders can be tested without payment credentials. Online checkout stays disabled until Razorpay keys are configured.

## Configure payments safely

1. Create a Razorpay account and use **test mode** first.
2. Put `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in `.env`. Never put the secret in frontend code or commit `.env`.
3. Configure the webhook URL `https://YOUR-DOMAIN/api/payments/webhook` in the Razorpay dashboard and set the same webhook secret as `RAZORPAY_WEBHOOK_SECRET`.
4. Test successful, failed, dismissed and delayed payment scenarios before going live.
5. Complete the provider's business/KYC and production activation requirements before accepting live payments.

The backend recalculates item prices from its own allowlist, creates the provider order, verifies the payment signature, checks the provider order receipt/amount, and only then marks an online order as `PAID`.

## Configure WhatsApp Cloud API

1. Set up a Meta app with WhatsApp Business Platform / Cloud API.
2. Add a recipient/test number and obtain a valid access token and phone-number ID.
3. Set `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, and `CAFE_WHATSAPP_TO` in `.env`. Use country code, e.g. `919978463006`, without plus sign.
4. Deploy behind HTTPS and test a COD order and a verified online payment.

The recipient number must be allowed/registered as required by Meta. Production messaging may require a suitable WhatsApp Business setup, permissions, templates or policy-compliant initiation. The code sends a free-form text notification and logs a failure if Meta rejects it. For production reliability, add a persistent notification queue and retry/reconciliation process.

## Menu notes

Prices were transcribed from the provided image. Burger cheese price is shown as an extra option note; the current cart charges the listed base burger price. If customers should select cheese, implement it as a server-validated modifier before launch.

## Before production launch

- Deploy to a Node-capable host with HTTPS (e.g. Render, Railway, or a VPS). GitHub Pages alone cannot run this backend.
- Use managed PostgreSQL for production rather than the included local SQLite starter, with backups and restricted access.
- Add an admin dashboard for accepting/rejecting orders, changing availability, updating menu prices and tracking order status.
- Add delivery zones/fees, GST/tax rules, cancellation/refund workflow and privacy/terms pages as applicable.
- Add idempotency and reconciliation for payment/webhook events, persistent WhatsApp retries, monitoring and backups.
- Restrict CORS to the exact live domain, keep secrets in host environment variables, and run end-to-end test orders before enabling live payments.

## API endpoints

- `GET /api/health` — reports whether payment and WhatsApp credentials are configured.
- `POST /api/orders` — validates customer/cart, recalculates server-side prices, creates order and (for online payment) a Razorpay order.
- `POST /api/payments/verify` — verifies Razorpay signature and provider amount/receipt before marking paid and sending WhatsApp notification.
- `POST /api/payments/webhook` — verifies Razorpay webhook signature and reconciles captured payments.

This is a starter implementation, not a deployed or audited production service. Do not accept live payments until configuration and tests are complete.
