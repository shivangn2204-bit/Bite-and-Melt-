import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const menu = [
  {category:'Burgers', name:'Bite and Melt Sp. Burger', price:40, cheesePrice:55, desc:'Our signature loaded burger', emoji:'🍔'},
  {category:'Burgers', name:'Veg Burger', price:40, cheesePrice:55, desc:'Crispy, fresh and satisfying', emoji:'🍔'},
  {category:'Pizza', name:'Capsi-Crunch Pizza', price:149, desc:'Fresh capsicum and onion', emoji:'🍕'},
  {category:'Pizza', name:'Spicy Peri Peri Veg. Pizza', price:159, desc:'Bold peri peri flavour', emoji:'🍕'},
  {category:'Pizza', name:'Veg Carnival Pizza', price:169, desc:'A colourful veggie mix', emoji:'🍕'},
  {category:'Pizza', name:'Signature Cheese Pizza', price:169, desc:'A rich, cheesy delight', emoji:'🍕'},
  {category:'Pizza', name:'Tandoori Paneer Pizza', price:179, desc:'Paneer with tandoori spices', emoji:'🍕'},
  {category:'Cold Coffee', name:'Cold Coffee', price:40, desc:'Chilled cafe classic', emoji:'🥤'},
  {category:'Cold Coffee', name:'Hazelnut Cold Coffee', price:50, desc:'Smooth hazelnut coffee', emoji:'🥤'},
  {category:'Cold Coffee', name:'Caramel Cold Coffee', price:50, desc:'Caramel coffee chill', emoji:'🥤'},
  {category:'Cold Coffee', name:'Chocolate Cold Coffee', price:50, desc:'Chocolatey and chilled', emoji:'🥤'},
  {category:'Sandwiches', name:'Bread Butter', price:40, desc:'Simple toasted comfort', emoji:'🥪'},
  {category:'Sandwiches', name:'Bread Butter Jam', price:40, desc:'Sweet and buttery', emoji:'🥪'},
  {category:'Sandwiches', name:'Veg Sandwich', price:50, desc:'Fresh veggie sandwich', emoji:'🥪'},
  {category:'Sandwiches', name:'Cheese Chutney Sandwich', price:60, desc:'Cheese with chutney', emoji:'🥪'},
  {category:'Sandwiches', name:'Corn Cheese Sandwich', price:70, desc:'Sweet corn and cheese', emoji:'🥪'},
  {category:'Sandwiches', name:'Veg. Cheese Grill', price:70, desc:'Grilled veggie and cheese', emoji:'🥪'},
  {category:'Sandwiches', name:'Aloo Cheese Chutney', price:70, desc:'Potato, cheese and chutney', emoji:'🥪'},
  {category:'Sandwiches', name:'Paneer Makhani', price:70, desc:'Creamy paneer filling', emoji:'🥪'},
  {category:'Sandwiches', name:'Cheese Chilli Sandwich', price:70, desc:'Cheesy with a chilli kick', emoji:'🥪'},
  {category:'Sandwiches', name:'Bite & Melt Sp. Sandwich', price:80, desc:'House special sandwich', emoji:'🥪'},
  {category:'Sandwiches', name:'Paneer Makhani Cheese', price:90, desc:'Paneer makhani with cheese', emoji:'🥪'},
  {category:'Garlic Bread', name:'Garlic Bread', price:70, desc:'Toasted garlic bread', emoji:'🍞'},
  {category:'Maggi', name:'Masala Maggi', price:50, desc:'Classic masala noodles', emoji:'🍜'},
  {category:'Maggi', name:'Veg. Maggi', price:60, desc:'Noodles with vegetables', emoji:'🍜'},
  {category:'Maggi', name:'Veg. Cheese Maggi', price:80, desc:'Veggie noodles with cheese', emoji:'🍜'},
  {category:'Fries', name:'Salted Fries', price:60, desc:'Golden salted fries', emoji:'🍟'},
  {category:'Fries', name:'Peri Peri Fries', price:70, desc:'Spicy peri peri seasoning', emoji:'🍟'},
  {category:'Fries', name:'Cheese Fries', price:80, desc:'Fries with cheesy topping', emoji:'🍟'}
];
const categories = ['All','Burgers','Pizza','Sandwiches','Cold Coffee','Garlic Bread','Maggi','Fries'];
const money = n => '₹' + Number(n).toFixed(0);

function App() {
  const [category,setCategory] = useState('All');
  const [cart,setCart] = useState([]);
  const [showCart,setShowCart] = useState(false);
  const [checkout,setCheckout] = useState(false);
  const [busy,setBusy] = useState(false);
  const [notice,setNotice] = useState('');
  const [form,setForm] = useState({name:'',phone:'',fulfilment:'Delivery',address:'',payment:'Online'});
  const visible = useMemo(()=>menu.filter(x=>category==='All'||x.category===category),[category]);
  const count = cart.reduce((s,x)=>s+x.qty,0);
  const total = cart.reduce((s,x)=>s+x.price*x.qty,0);
  const add = item => { setCart(old=>{const found=old.find(x=>x.name===item.name);return found?old.map(x=>x.name===item.name?{...x,qty:x.qty+1}:x):[...old,{...item,qty:1}];}); setNotice(`${item.name} added to cart`); setTimeout(()=>setNotice(''),1800); };
  const changeQty = (name,delta) => setCart(old=>old.map(x=>x.name===name?{...x,qty:x.qty+delta}:x).filter(x=>x.qty>0));
  const update = e => setForm({...form,[e.target.name]:e.target.value});
  async function placeOrder(e) {
    e.preventDefault(); if(!cart.length) return;
    setBusy(true); setNotice('');
    try {
      const res = await fetch('/api/orders', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:form,items:cart.map(({name,price,qty,category})=>({name,price,qty,category}))})});
      const data = await res.json(); if(!res.ok) throw new Error(data.error||'Could not create order');
      if(form.payment==='Online') {
        if(!data.razorpayKeyId) throw new Error('Online payment is not configured yet. Choose Cash on Delivery or contact the cafe.');
        const script = document.createElement('script'); script.src='https://checkout.razorpay.com/v1/checkout.js';
        await new Promise((resolve,reject)=>{script.onload=resolve;script.onerror=reject;document.body.appendChild(script);});
        const rzp = new window.Razorpay({key:data.razorpayKeyId,amount:data.amountPaise,currency:'INR',name:'Bite and Melt',description:`Order ${data.orderId}`,order_id:data.razorpayOrderId,prefill:{name:form.name,contact:form.phone},theme:{color:'#12a9ed'},
          handler:async response=>{
            try {const verify=await fetch('/api/payments/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...response,orderId:data.orderId})});const result=await verify.json();if(!verify.ok)throw new Error(result.error||'Payment verification failed');setNotice(`Payment verified! Order ${data.orderId} confirmed.`);setCart([]);setCheckout(false);setShowCart(false);}
            catch(err){setNotice(err.message+' Please contact the cafe with order '+data.orderId);}
          },
          modal:{ondismiss:()=>setNotice(`Payment not completed. Your order ${data.orderId} is not confirmed.`)}
        }); rzp.open();
      } else {
        setNotice(`Order ${data.orderId} placed for Cash on Delivery. The cafe will confirm shortly.`);
        setCart([]);setCheckout(false);setShowCart(false);
      }
    } catch(err) {setNotice(err.message||'Something went wrong');}
    finally {setBusy(false);}
  }
  return <div className="site">
    <header className="nav"><a className="brand" href="#"><span className="brand-icon">🍔</span><span>Bite <i>and</i> Melt<small>FRESH BITES. BIG SMILES.</small></span></a><nav><a href="#home">Home</a><a href="#menu">Menu</a><a href="#how">How it works</a></nav><button className="cart-pill" onClick={()=>setShowCart(true)}>🛒 Cart <b>{count}</b></button></header>
    <main>
      <section className="hero" id="home"><div className="hero-copy"><span className="eyebrow"><span/> GOOD FOOD, GOOD MOOD</span><h1>Where every bite <em>melts your heart.</em></h1><p>Fresh bites. Big smiles. Your favourite cafe treats, just a few taps away.</p><div className="hero-actions"><a className="btn yellow" href="#menu">Explore menu <span>↗</span></a><button className="btn outline" onClick={()=>setShowCart(true)}>Order now</button></div><div className="hero-proof"><span>⭐ Freshly made</span><span>⚡ Easy ordering</span><span>💛 Made with love</span></div></div><div className="hero-art"><div className="sun-disc"/><div className="food-emoji burger">🍔</div><div className="food-emoji coffee">🥤</div><div className="food-emoji fries">🍟</div><div className="scribble">Good food<br/>Good mood!</div><div className="hero-caption">THE HAPPY<br/>FOOD PLACE</div></div><div className="blue-splash"></div></section>
      <section className="category-strip" aria-label="Menu categories">{categories.slice(1).map((c,i)=><button key={c} className={`category-chip ${category===c?'selected':''}`} onClick={()=>{setCategory(c);document.querySelector('#menu').scrollIntoView({behavior:'smooth'});}}><span>{['🍔','🍕','🥪','🥤','🍞','🍜','🍟'][i]}</span>{c}<b>↗</b></button>)}</section>
      <section className="menu-section" id="menu"><div className="section-heading"><div><span className="eyebrow">MADE FRESH FOR YOU</span><h2>Our <em>special menu</em></h2><p>Big flavours. Happy prices. Find your new favourite.</p></div><div className="menu-controls"><button className="btn outline small" onClick={()=>setCategory('All')}>View all items ↗</button><button className="cart-mobile" onClick={()=>setShowCart(true)}>🛒 {count}</button></div></div><div className="filters">{categories.map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="product-grid">{visible.map((item,i)=><article className="product" key={item.name} style={{'--delay':`${(i%8)*55}ms`}}><div className={`product-art art-${item.category.toLowerCase().replaceAll(' ','-')}`}><span className="product-emoji">{item.emoji}</span><span className="fresh-tag">FRESH</span></div><div className="product-info"><div className="product-category">{item.category}</div><h3>{item.name}</h3><p>{item.desc}</p><div className="product-bottom"><strong>{money(item.price)}</strong><button onClick={()=>add(item)} aria-label={`Add ${item.name} to cart`}>＋ Add</button></div>{item.cheesePrice&&<small className="extra">Cheese option: {money(item.cheesePrice)}</small>}</div></article>)}</div></section>
      <section className="how" id="how"><div><span className="step-icon">🛒</span><h3>Pick your favourites</h3><p>Add the food you love to your cart.</p></div><span className="step-arrow">→</span><div><span className="step-icon">💳</span><h3>Pay your way</h3><p>Secure online payment or cash on delivery.</p></div><span className="step-arrow">→</span><div><span className="step-icon whatsapp">☏</span><h3>Order to WhatsApp</h3><p>Confirmed order details reach the cafe.</p></div></section>
      <section className="cta"><div><span className="eyebrow">YOUR NEXT HAPPY BITE</span><h2>Hungry? Let's <em>make it melt.</em></h2><p>Great food is only a few clicks away.</p></div><a className="btn dark" href="#menu">Order your favourites ↗</a><span className="cta-food">🍕 🍔 🍟</span></section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-icon">🍔</span><span>Bite <i>and</i> Melt<small>FRESH BITES. BIG SMILES.</small></span></a><p>Fresh bites. Big smiles. Made with 💛</p><a href="https://wa.me/919978463006" target="_blank" rel="noreferrer">Contact cafe on WhatsApp ↗</a><small>Menu prices are shown in INR. Delivery charges, if any, are confirmed by the cafe.</small></footer>
    {notice&&<div className="toast" role="status">{notice}<button onClick={()=>setNotice('')}>×</button></div>}
    {showCart&&<div className="overlay" onClick={()=>setShowCart(false)}><aside className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><div><span className="eyebrow">YOUR ORDER</span><h2>Your cart <span>({count})</span></h2></div><button className="close" onClick={()=>setShowCart(false)}>×</button></div>{!cart.length?<div className="empty"><span>🛒</span><h3>Your cart is waiting</h3><p>Add something delicious from our menu.</p><button className="btn yellow" onClick={()=>{setShowCart(false);document.querySelector('#menu').scrollIntoView({behavior:'smooth'});}}>Explore menu</button></div>:<><div className="cart-items">{cart.map(item=><div className="cart-row" key={item.name}><span className="cart-emoji">{item.emoji}</span><div className="cart-detail"><b>{item.name}</b><small>{money(item.price)} each</small><div className="qty"><button onClick={()=>changeQty(item.name,-1)}>−</button><span>{item.qty}</span><button onClick={()=>changeQty(item.name,1)}>＋</button></div></div><strong>{money(item.price*item.qty)}</strong></div>)}</div><div className="cart-total"><span>Subtotal</span><strong>{money(total)}</strong></div>{!checkout?<button className="btn yellow full" onClick={()=>setCheckout(true)}>Continue to checkout →</button>:<form className="checkout" onSubmit={placeOrder}><h3>Delivery details</h3><label>Full name<input name="name" required value={form.name} onChange={update} placeholder="Your name"/></label><label>Mobile number<input name="phone" required pattern="[0-9+ ]{10,16}" value={form.phone} onChange={update} placeholder="10-digit phone number"/></label><label>Order type<select name="fulfilment" value={form.fulfilment} onChange={update}><option>Delivery</option><option>Pickup</option></select></label>{form.fulfilment==='Delivery'&&<label>Full delivery address<textarea name="address" required value={form.address} onChange={update} placeholder="House, street, area, landmark"/></label>}<label>Payment method<select name="payment" value={form.payment} onChange={update}><option value="Online">Online payment (Razorpay)</option><option value="Cash on Delivery">Cash on Delivery / pay at pickup</option></select></label><p className="secure-note">🔒 Online payments are only marked paid after server-side signature verification.</p><button className="btn yellow full" disabled={busy}>{busy?'Please wait…':`Place order · ${money(total)}`}</button><button type="button" className="text-button" onClick={()=>setCheckout(false)}>Back to cart</button></form>}</>}</aside></div>}
  </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
